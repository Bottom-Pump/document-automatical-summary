import os
import datetime
import pymysql
from volcenginesdkarkruntime import Ark
from rouge_chinese import Rouge  # 使用中文ROUGE计算库
import jieba  # 中文分词库
import PyPDF2  # PDF处理库
from docx import Document  # DOCX处理库

# 初始化DeepSeek模型客户端
client = Ark(
    base_url="https://ark.cn-beijing.volces.com/api/v3",
    # api_key=os.environ.get("ARK_API_KEY"),  # 从环境变量获取API密钥
    api_key="707f20c5-XXXXXX",  # 为简化,此demo直接硬编码apikey
)

# 初始化中文ROUGE计算器
rouge = Rouge()


# 创建MySQL数据库连接
def create_db_connection():
    return pymysql.connect(
        host='localhost',
        port=3306,
        user='root',
        password='123456',
        database='knowledge_base',
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )


# 获取数据库连接
conn = create_db_connection()
cursor = conn.cursor()


def extract_document_content(file_path):
    """提取文档正文内容（不使用textract）"""
    try:
        if file_path.endswith('.pdf'):
            # 使用PyPDF2处理PDF
            with open(file_path, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                text = ""
                for page in reader.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
                return text

        elif file_path.endswith('.docx'):
            # 使用python-docx处理DOCX
            doc = Document(file_path)
            return "\n".join([para.text for para in doc.paragraphs])

        else:  # 假设为文本文件
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()

    except Exception as e:
        print(f"Error extracting {file_path}: {str(e)}")
        return ""


def generate_summary(document_content):
    """使用DeepSeek模型生成摘要"""
    if not document_content.strip():
        return ""

    # 截取前6000字符（模型可能有长度限制）
    content = document_content[:6000]

    try:
        response = client.chat.completions.create(
            model="deepseek-v3-241226",
            messages=[
                {"role": "system",
                 "content": "你是一个专业的技术文档摘要生成器。请用一句话（不超过25字）准确概括文档核心内容。"},
                {"role": "user", "content": f"请为以下技术文档生成一句话摘要：\n\n{content}"}
            ],
            max_tokens=50,  # 限制生成长度
            temperature=0.3  # 降低随机性
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"摘要生成失败: {str(e)}")
        return ""


def preprocess_text(text):
    """预处理文本：使用jieba分词并用空格连接"""
    return ' '.join(jieba.cut(text))


def calculate_rouge1(reference, candidate):
    """计算中文ROUGE-1分数（使用F1值）"""
    if not reference or not candidate:
        return 0.0

    try:
        # 预处理文本
        ref_processed = preprocess_text(reference)
        cand_processed = preprocess_text(candidate)

        # 计算ROUGE分数
        scores = rouge.get_scores(cand_processed, ref_processed)

        # 返回rouge-1的f1值
        return scores[0]['rouge-1']['f']
    except Exception as e:
        print(f"ROUGE计算错误: {str(e)}")
        return 0.0


def process_document(document_id):
    """处理单个文档：生成摘要并评估"""
    try:
        # 获取文档信息
        cursor.execute("SELECT title, file_path, reference_summary FROM documents WHERE id=%s", (document_id,))
        doc = cursor.fetchone()
        if not doc:
            return

        title, file_path, ref_summary = doc['title'], doc['file_path'], doc['reference_summary']

        # 提取内容并生成摘要
        content = extract_document_content(file_path)
        gen_summary = generate_summary(content)

        if not gen_summary:
            print(f"文档 {title} 摘要生成失败")
            return

        # 保存摘要
        cursor.execute(
            "INSERT INTO summaries (document_id, summary) VALUES (%s, %s)",
            (document_id, gen_summary)
        )
        summary_id = cursor.lastrowid

        # 如果有参考摘要，则计算ROUGE分数
        if ref_summary:
            rouge1 = calculate_rouge1(ref_summary, gen_summary)
            cursor.execute(
                "INSERT INTO summary_metrics (summary_id, rouge1) VALUES (%s, %s)",
                (summary_id, rouge1)
            )
            print(f"文档 {title} 处理完成 - ROUGE-1: {rouge1:.4f}")
        else:
            print(f"文档 {title} 处理完成 - 无参考摘要")

        conn.commit()
    except Exception as e:
        print(f"处理文档 {document_id} 时出错: {str(e)}")
        conn.rollback()


def batch_process_documents(batch_size=10):
    """批量处理文档"""
    try:
        # 获取未处理的文档ID
        cursor.execute('''
            SELECT d.id 
            FROM documents d
            LEFT JOIN summaries s ON d.id = s.document_id
            WHERE s.id IS NULL
            LIMIT %s
        ''', (batch_size,))

        doc_ids = [row['id'] for row in cursor.fetchall()]

        if not doc_ids:
            print("所有文档已处理完成")
            return

        print(f"开始批量处理 {len(doc_ids)} 个文档...")

        for doc_id in doc_ids:
            process_document(doc_id)

        print("批量处理完成")
    except Exception as e:
        print(f"批量处理失败: {str(e)}")


def get_low_quality_documents():
    """获取质量差的文档（ROUGE-1 < 0.5）"""
    try:
        cursor.execute('''
            SELECT d.title, m.rouge1
            FROM documents d
            JOIN summaries s ON d.id = s.document_id
            JOIN summary_metrics m ON s.id = m.summary_id
            WHERE m.rouge1 < 0.5
            ORDER BY m.evaluated_at DESC
        ''')

        results = cursor.fetchall()

        if not results:
            print("未找到低质量文档")
            return

        print("\n低质量文档列表 (ROUGE-1 < 0.5):")
        print("-" * 50)
        for row in results:
            print(f"{row['title']} - 分数: {row['rouge1']:.4f}")
    except Exception as e:
        print(f"查询低质量文档失败: {str(e)}")


def add_sample_documents():
    """添加示例文档到数据库"""
    try:
        sample_docs = [
            ("Docker_K8S", "D:/docs/Docker_K8S.pdf", "Docker容器技术与 Kubernetes 架构及应用实践"),
            ("软件设计文档", "D:/docs/软件设计文档.docx", "基于 SpringBoot 的读书笔记共享平台设计与实现"),
            ("error_code", "D:/docs/error_code.txt", "MySQL 服务器和客户端错误代码及消息解析")
        ]

        cursor.executemany(
            "INSERT INTO documents (title, file_path, reference_summary) VALUES (%s, %s, %s)",
            sample_docs
        )
        conn.commit()
        print(f"添加了 {len(sample_docs)} 个示例文档")
    except Exception as e:
        print(f"添加示例文档失败: {str(e)}")


if __name__ == "__main__":
    try:
        # 添加示例文档
        add_sample_documents()

        # 批量处理文档
        batch_process_documents()

        # 获取低质量文档
        get_low_quality_documents()
    finally:
        # 关闭连接
        cursor.close()
        conn.close()